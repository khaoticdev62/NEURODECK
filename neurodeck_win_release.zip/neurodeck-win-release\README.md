# NEURODECK

A native-feeling AI terminal interface for SteamOS Game Mode on the Steam Deck.

## Features

- **TUI Interface**: Built with Bubble Tea for a terminal-native feel.
- **AI Integration**: Powered by Gemini API (or Ollama) for intelligent responses.
- **Local Vector Memory**: Long-term memory and RAG using `chromem-go`.
- **Plugin System**: Extend functionality with Lua scripts.
- **Voice Support**: Speech-to-Text (STT) and Text-to-Speech (TTS) support.
- **Cross-Platform**: Works on both Windows (for development) and Linux (SteamOS).

## Installation

### Prerequisites

- Go 1.21 or later.
- Gemini API Key (set as `GEMINI_API_KEY` environment variable).

### Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/thecr/neurodeck.git
   cd neurodeck
   ```

2. Build the project:
   ```bash
   go build ./cmd/neurodeck
   ```

3. Run it:
   ```bash
   ./neurodeck
   ```

## Usage

- Type your message and press `Enter` to talk to the AI.
- Use `/help` to see available commands.
- Use `Ctrl+B` to execute a Lua script from chat.
- Use `Ctrl+S` to save the session.
- Use `Ctrl+R` to record audio (if supported).

## Documentation

- [User Guide](docs/USER_GUIDE.md)

## License

MIT
