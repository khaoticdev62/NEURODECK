#!/bin/bash

# NEURODECK Installation Script for SteamOS (Tauri edition)

set -e

echo "Starting NEURODECK installation..."

# Create directories
echo "Creating directories..."
mkdir -p "$HOME/Applications/neurodeck"
mkdir -p "$HOME/Applications/neurodeck/sessions"
mkdir -p "$HOME/Applications/neurodeck/exports"
mkdir -p "$HOME/Applications/neurodeck/data/memory"

# Build the project
echo "Building NEURODECK..."
if command -v npm &> /dev/null && command -v cargo &> /dev/null; then
    # Install dependencies
    npm install --prefix frontend
    # Build Tauri app
    npx @tauri-apps/cli build
    if [ -f "src-tauri/target/release/neurodeck" ]; then
        cp src-tauri/target/release/neurodeck "$HOME/Applications/neurodeck/neurodeck"
    else
        cp src-tauri/target/release/app "$HOME/Applications/neurodeck/neurodeck"
    fi
else
    echo "NPM or Cargo not found. Looking for local binary..."
    if [ -f "src-tauri/target/release/neurodeck" ]; then
        echo "Found neurodeck release binary. Copying..."
        cp src-tauri/target/release/neurodeck "$HOME/Applications/neurodeck/neurodeck"
    elif [ -f "src-tauri/target/release/app" ]; then
        echo "Found app release binary. Copying..."
        cp src-tauri/target/release/app "$HOME/Applications/neurodeck/neurodeck"
    elif [ -f "src-tauri/target/release/neurodeck.exe" ]; then
        echo "Found neurodeck Windows exe. Copying..."
        cp src-tauri/target/release/neurodeck.exe "$HOME/Applications/neurodeck/neurodeck.exe"
    elif [ -f "src-tauri/target/release/app.exe" ]; then
        echo "Found app Windows exe. Copying..."
        cp src-tauri/target/release/app.exe "$HOME/Applications/neurodeck/neurodeck.exe"
    else
        echo "Error: No build tools found and no release binary available."
        echo "Please build the project on your development machine."
        exit 1
    fi
fi

# Copy launch_gamescope.sh if present
if [ -f "launch_gamescope.sh" ]; then
    echo "Copying launch_gamescope.sh..."
    cp launch_gamescope.sh "$HOME/Applications/neurodeck/launch_gamescope.sh"
    chmod +x "$HOME/Applications/neurodeck/launch_gamescope.sh"
fi

# Make binary executable
if [ -f "$HOME/Applications/neurodeck/neurodeck" ]; then
    chmod +x "$HOME/Applications/neurodeck/neurodeck"
fi

echo "Installation complete!"
echo "You can run NEURODECK from $HOME/Applications/neurodeck/neurodeck"
echo "Make sure to set your GEMINI_API_KEY environment variable!"
