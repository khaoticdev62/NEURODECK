# NEURODECK Design Tokens + Component Library v1.0 Package

Generated: 2026-06-09T21:50:48Z

## Included Files

- `NEURODECK_Design_Tokens_Component_Library_v1.0.md` — main specification
- `tokens.json` — token source of truth
- `tokens.css` — CSS custom properties
- `theme.blacksite.css`
- `theme.tactical-glass.css`
- `theme.high-contrast.css`
- `theme.colorblind-safe.css`
- `tailwind.config.ts` — Tailwind mapping
- `component-registry.json`
- `NEURODECK_Component_Registry_v1.0.csv`
- `NEURODECK_Design_System_Implementation_Prompt_v1.0.md`

## Target Stack

Electron + React + TypeScript + Tailwind CSS.

## Target Device

Steam Deck LCD at 1280 × 800, with desktop/docked fallbacks.
