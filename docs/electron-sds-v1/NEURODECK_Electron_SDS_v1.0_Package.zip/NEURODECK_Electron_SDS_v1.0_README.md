# NEURODECK Electron SDS v1.0 Package

This package contains implementation-grade technical design docs for building NEURODECK as an Electron + React + TypeScript + Tailwind application.

Included:

- NEURODECK_Electron_SDS_v1.0.md
- NEURODECK_IPC_Contract_Registry_v1.0.md
- NEURODECK_Service_Boundary_Map_v1.0.md
- NEURODECK_Folder_Structure_v1.0.md
- NEURODECK_Data_Model_Schemas_v1.0.md
- NEURODECK_Security_Implementation_Checklist_v1.0.md
- NEURODECK_Hermes_Extension_Contract_v1.0.md
- NEURODECK_Electron_SDS_Implementation_Prompt_v1.0.md
- NEURODECK_SDS_schemas/*.json

Use this package after the Canonical Production PRD v1.0. The PRD defines product scope; this SDS defines engineering execution.
