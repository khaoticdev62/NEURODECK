# NEURODECK PromptDrive — Production QA + Release Gate Pack

## Purpose

This document defines the final QA, validation, and release gates required before PromptDrive can be considered production-ready for Steam Deck-first usage.

PromptDrive is not complete when the UI looks good. It is complete when the system can be used from boot to prompt execution to macro replay with a controller only, under real Steam Deck constraints, without dead-end states, fake data, broken IPC, or unsafe command execution.

---

# 1. Release Gate Summary

PromptDrive v1.0 may only ship when all gates below pass:

| Gate | Status Required |
|---|---|
| Build Gate | Pass |
| Type Safety Gate | Pass |
| Lint Gate | Pass |
| Unit Test Gate | Pass |
| Integration Test Gate | Pass |
| Controller Navigation Gate | Pass |
| Steam Deck 1280x800 Gate | Pass |
| IPC Security Gate | Pass |
| Prompt Pack Gate | Pass |
| Macro Replay Gate | Pass |
| Accessibility Gate | Pass |
| Offline Mode Gate | Pass |
| Packaging Gate | Pass |

No partial credit. No “works on my machine.” No vibes-based shipping.

---

# 2. Build Gate

## Required Commands

```bash
pnpm install
pnpm build
pnpm lint
pnpm test
```

## Pass Criteria

- All packages compile.
- No unresolved exports.
- No broken TypeScript paths.
- No missing workspace dependencies.
- Electron main process compiles.
- Preload API compiles.
- Renderer compiles.
- Tailwind builds without config errors.

## Fail Conditions

- Any TypeScript error.
- Any missing package export.
- Any Electron boot crash.
- Any renderer white screen.
- Any dependency only working because of a global install.

---

# 3. Type Safety Gate

## Required

```bash
pnpm -r typecheck
```

## Rules

- No `any` unless justified with a comment.
- No unsafe IPC payloads.
- No untyped prompt templates.
- No untyped macro payloads.
- No untyped controller bindings.

## Required Shared Types

```ts
PromptTemplate
PromptSlot
CommandDefinition
MacroDefinition
MacroStep
AgentDefinition
ControllerProfile
ControllerBinding
Suggestion
```

---

# 4. IPC Security Gate

## Required Electron Security Rules

- Renderer cannot access Node directly.
- `contextIsolation: true`.
- `nodeIntegration: false`.
- Preload exposes only `window.neurodeck`.
- All IPC payloads validated.
- No arbitrary command execution from renderer.
- No direct filesystem writes from renderer.

## Required IPC Channels

```text
prompt:list
prompt:execute
command:list
command:execute
macro:start
macro:stop
macro:execute
agent:list
agent:switch
controller:getProfile
controller:updateBinding
settings:get
settings:update
```

## Pass Criteria

- Invalid payloads are rejected.
- Unknown channels are not exposed.
- Destructive commands require confirmation.
- Main process owns filesystem and command execution.

---

# 5. Controller Navigation Gate

## Required Steam Deck Controls

| Input | Required Behavior |
|---|---|
| L4 tap | Open Prompt Library |
| L4 hold | Open Agent Wheel |
| L5 tap | Save / Pin Prompt |
| R4 tap | Accept Suggestion |
| R4 hold | Regenerate / Re-rank |
| R5 tap | Open Command Palette |
| R5 hold | Execute Prompt |
| L4 + R4 | Complete Prompt |
| L5 + R5 | Start / Stop Macro Recording |
| B | Back / cancel |
| Hold B | Emergency cancel |
| D-pad | Move focus / suggestions |
| A | Confirm |
| X | Edit selected slot |
| Y | Context menu |

## Pass Criteria

- Every primary screen is navigable without keyboard.
- B always exits modal or backs out one level.
- No focus trap exists.
- No controller action silently fails.
- All button hints match actual behavior.

---

# 6. Focus Graph Gate

Every interactive screen must define a focus graph.

## Required Focus Node Shape

```ts
interface FocusNode {
  id: string;
  up?: string;
  down?: string;
  left?: string;
  right?: string;
  enter?: string;
  back?: string;
}
```

## Pass Criteria

- Every focusable element has a reachable path.
- Every modal has a back/cancel route.
- Every destructive confirmation has explicit accept/cancel focus states.
- Controller navigation works at 1280x800 and docked 1920x1080.

---

# 7. Prompt Composer Gate

## Required Flow

```text
Open Prompt Composer
Select Prompt Template
Fill Required Slots
Use Autocomplete
Preview Final Prompt
Execute Prompt
Save Prompt
Save as Macro
```

## Pass Criteria

- No required slot can be left empty.
- Preview updates after every slot change.
- Autocomplete suggestions appear under 50ms.
- R4 accepts selected suggestion.
- R5 hold executes only valid prompts.
- Medium/destructive actions require confirmation.

---

# 8. Autocomplete Gate

## Required Sources

```text
Prompt templates
Prompt blocks
Commands
Macros
Agents
Recent prompts
Pinned prompts
Files
Framework names
Languages
Testing strategies
Security standards
```

## Required Ranking Formula

```text
score =
  prefixMatch * 35
+ fuzzyMatch * 20
+ contextMatch * 20
+ recentUsage * 10
+ pinnedItem * 10
+ personaMatch * 5
```

## Pass Criteria

- Suggestion latency under 50ms for normal prompt packs.
- Suggestions are stable under repeated navigation.
- Suggestions can be navigated with D-pad.
- Suggestions can be accepted with R4.
- Empty query returns useful defaults.

---

# 9. Prompt Pack Gate

## Required Prompt Pack Structure

```text
prompt-packs/<pack-id>/
  manifest.json
  templates/*.json
  macros/*.json
```

## Required Manifest Fields

```json
{
  "id": "coding.production",
  "version": "1.0.0",
  "title": "Production Coding Pack",
  "author": "Khaotic Labs"
}
```

## Pass Criteria

- Invalid packs are rejected safely.
- Corrupted packs do not crash app.
- Duplicate template IDs are detected.
- Prompt slots validate.
- Import/export works.

---

# 10. Macro Replay Gate

## Required Flow

```text
L5 + R5 start recording
Perform actions
L5 + R5 stop recording
Name macro
Bind macro
Replay macro
Recover from failure
```

## Pass Criteria

- Macro steps persist to SQLite.
- Replay follows exact saved order.
- Dangerous steps pause for confirmation.
- Failed step shows exact failure reason.
- Macro replay can be cancelled with Hold B.

---

# 11. Agent Runtime Gate

## Required Built-In Agents

```text
Architect
Developer
Refactor
Testing
Security
UX
Documentation
Release
Steam Deck QA
```

## Pass Criteria

- Agent can be selected with controller.
- Agent modifies prompt execution context.
- Agent system prompt is visible for review.
- Agent switching persists per session.
- No hidden destructive behavior.

---

# 12. Steam Deck Performance Gate

## Required Targets

| Metric | Target |
|---|---|
| Resolution | 1280x800 |
| UI FPS | 60 FPS target |
| Render budget | 16.67ms |
| Autocomplete latency | <50ms |
| Input latency | <16ms perceived |
| App memory target | <350MB excluding external models |

## Pass Criteria

- UI is readable at 1280x800.
- No text requires tiny-font squint mode.
- No modal overflows screen.
- No critical action requires touchscreen.
- Docked mode does not break layout.

---

# 13. Accessibility Gate

## Required Modes

```text
High Contrast
Low Vision
Reduced Motion
Colorblind
Dyslexia Friendly
Large Text
Controller Assist
```

## Pass Criteria

- All interactive items have visible focus.
- Button hints are readable.
- Reduced motion disables nonessential animation.
- Large text does not break layout.
- Keyboard fallback exists for every controller action.

---

# 14. Offline Mode Gate

## Required Behavior

- App launches without internet.
- Prompt packs load offline.
- Macros work offline.
- Controller profiles work offline.
- Local provider configuration works offline.
- Cloud model errors are handled gracefully.

## Fail Conditions

- App hangs while waiting for network.
- Prompt Composer requires cloud service.
- Prompt Library fails without internet.

---

# 15. Packaging Gate

## Required Targets

```text
Windows installer
Linux AppImage
Steam Deck install script
Portable dev build
```

## Steam Deck Package Requirements

```text
.desktop launcher
Game Mode launch compatibility
Controller profile documentation
Install script
Uninstall script
Logs directory
Config directory
```

## Pass Criteria

- App launches from Steam Deck Desktop Mode.
- App can be added to Steam as non-Steam game.
- Game Mode launch path is documented.
- Logs are written to a known location.

---

# 16. Final Release Checklist

```text
[ ] pnpm install passes
[ ] pnpm build passes
[ ] pnpm lint passes
[ ] pnpm test passes
[ ] Electron app boots
[ ] Renderer loads
[ ] SQLite migrations run
[ ] Prompt packs seed
[ ] Prompt Composer works
[ ] Autocomplete works
[ ] Prompt execution works
[ ] Macro recording works
[ ] Macro replay works
[ ] Controller mapper works
[ ] L4/L5/R4/R5 mapped
[ ] B always backs out
[ ] No focus traps
[ ] IPC validated
[ ] Offline mode works
[ ] Steam Deck 1280x800 verified
[ ] Docked mode verified
[ ] Accessibility modes verified
[ ] Installer generated
[ ] Release notes generated
```

---

# 17. Definition of Production Ready

PromptDrive is production-ready when a user can:

1. Launch NEURODECK on Steam Deck.
2. Navigate entirely with controller.
3. Open PromptDrive Composer.
4. Select a production prompt template.
5. Fill slots with autocomplete.
6. Preview the final prompt.
7. Execute through an agent.
8. Save the workflow as a macro.
9. Replay the macro.
10. Recover from mistakes safely.
11. Do all of the above offline.

That is the release bar.

Anything less is not v1.0.
