# NEURODECK PromptDrive — Full Specification Package

## Purpose
This package contains the complete production specification suite for **NEURODECK PromptDrive**, a Steam Deck-native controller coding, programming, and elite prompt-generation system.

PromptDrive is designed as a controller-first AI workstation layer for Steam Deck and desktop environments using **Electron + React + TypeScript + Tailwind**, with support for structured prompt libraries, autocomplete, macros, agents, memory, plugins, Steam Deck mappings, and production QA gates.

## Package Contents

- `00_MASTER/` — master overview, document map, and implementation order
- `01_PRD_SDS/` — PRD and software design specification
- `02_UX_BIBLE/` — Steam Deck controller UX volumes
- `03_DESIGN_SYSTEM/` — Tactical Glass design system and component library
- `04_ENGINEERING/` — engineering volumes, repo structure, tickets, and schemas
- `05_PROMPT_LIBRARY_AGENTS_MEMORY/` — prompt library, agent system, and memory engine
- `06_PLUGIN_SECURITY_QA_RELEASE/` — plugin SDK, accessibility, telemetry, QA, release, and security
- `07_IMPLEMENTATION_HANDOFFS/` — vertical slice, runbook, AI coding-agent prompt, QA gates
- `08_SCAFFOLD/` — existing downloadable repo scaffold ZIP

## Recommended Build Order

1. Read `00_MASTER/MASTER_INDEX.md`
2. Implement repo scaffold from `08_SCAFFOLD/neurodeck-promptdrive-scaffold.zip`
3. Follow `07_IMPLEMENTATION_HANDOFFS/PROMPTDRIVE_REPO_EXECUTION_RUNBOOK.md`
4. Build the first vertical slice from `07_IMPLEMENTATION_HANDOFFS/PROMPTDRIVE_VERTICAL_SLICE_BUILD_PACK.md`
5. Validate against `06_PLUGIN_SECURITY_QA_RELEASE/Volume_XII_QA_Certification.md`

## North Star
PromptDrive should feel like a controller-native AI coding cockpit: SteamOS-native, tactical, fast, readable, remappable, offline-capable, and fully usable without a keyboard.
